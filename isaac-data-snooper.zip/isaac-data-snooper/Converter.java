import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.FileWriter;
import java.io.IOException;
import java.util.TreeSet;
import java.text.DecimalFormat;

class Converter {

    // This is a sample program meant to show how the data could be used.
    // The data is fed in, processed, and returned as a text file containing how often each item has been picked up.
    // It's not my best code, but it demonstrates the mod's purpose pretty well.

    public static void main(String[] args) {
        // IMPORTANT: Replace this value with the file path of the folder! (use two backslashes per slash)
        File root = new File("C:\\FILES\\LEADING\\TO\\SOMEWHERE");



        ArrayList<String[]> a = new ArrayList<String[]>();
        HashMap<Integer, Integer> items_found = new HashMap<Integer, Integer>();
        HashMap<Integer, Integer> items_get = new HashMap<Integer, Integer>();
        HashMap<Integer, String> lookup = new HashMap<Integer, String>();
        ArrayList<String> unique_seeds = new ArrayList<String>();

        for (String file : root.list()) {
            //System.out.println(file);
            if (file.length() >= 4) {
                if (file.substring(0,4).equals("save")) {
                    File f = new File("save1.dat");
            
        

        try {
            Scanner scan = new Scanner(f);
            String rawText = scan.nextLine();
            rawText = rawText.substring(1,rawText.length() - 1).replace("\"","");
            rawText = rawText.replace("\"","");
            a.add(rawText.split(","));
            for (String[] sbar : a) {
                for (String s : sbar) {
                    //System.out.println(s);
                    String[] ss = s.split("\\|");
                    if (ss[0].equals("DEFINE")) {
                        lookup.put(Integer.parseInt(ss[1]),ss[2]);
                        //System.out.println("Entry " + lookup.size() + ": [" + ss[1] + ", " + ss[2] + "]");
                    }
                    else if (ss[0].charAt(4) == ' ' && !unique_seeds.contains(ss[0])) {
                        unique_seeds.add(ss[0]);
                    }
                    if (ss.length > 7) {
                        if (ss[6].equals("SAW")) {
                            items_found.put(Integer.parseInt(ss[7]),items_found.getOrDefault(Integer.parseInt(ss[7]), 0) + 1);
                        }
                        else if (ss[6].equals("GET")) {
                            items_get.put(Integer.parseInt(ss[7]),items_get.getOrDefault(Integer.parseInt(ss[7]), 0) + 1);
                        }
                    }
                }
            }
            //System.out.println(rawText);
            scan.close();
        }
        catch (FileNotFoundException fnfe) {}
            }}
        }
        
        try {
            FileWriter fw = new FileWriter("output.txt");
            for (int i : new TreeSet<>(items_found.keySet())) {
                //System.out.println(lookup.getOrDefault(i, String.valueOf(i)) + ": " + items_found.get(i));
            }
            for (int j : new TreeSet<>(items_get.keySet())) {
                double chance = (double)items_get.getOrDefault(j,0) / (double)items_found.getOrDefault(j,1);
                //System.out.println(lookup.get(j) + ": " + new DecimalFormat("##.00").format(chance*100) + "%");
                fw.write(lookup.get(j) + ": " + new DecimalFormat("##.00").format(chance*100) + "%" + '\n');
                //System.out.println(lookup.getOrDefault(j, String.valueOf(j)) + ": " + items_get.get(j));
            }
            
            fw.close();
        }
        catch (IOException ioe) {}
    }

}